FACE FRONT
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Face Front is a full-keyboard caps set in "comic book" style. I drew the master sample with a cheap inkpen on a single piece of pocket notebook paper, in Schlotsky's at the corner of 6th and Congress here in Austin. I had a few minutes to kill and thought to myself "How hard can drawing comicbook lettering really be?" Once again, I demonstrate why I'm a writer, not a calligrapher. Hats off to those who make GOOD comicbook fonts. Here, for your amusement, is my crummy one.

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind. Contact me at sjohn@cumberlandgames.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0

